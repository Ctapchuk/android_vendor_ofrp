## Systemless Xposed For SDK 27 (Android 8.1)

Please install my modified [XposedInstaller(3.1.5)](https://forum.xda-developers.com/attachment.php?attachmentid=4393853&d=1516377687) to properly detect Systemless Xposed. The APK is signed by my personal key, you might need to uninstall other versions before installing mine.

### [More details in support thread](http://forum.xda-developers.com/showthread.php?t=3388268)

## Changelog

#### v90.1-beta3
- Update to official v90-beta3

#### v90.1-beta2
- Fix selinux context on several binaries

#### v90.0-beta2
- Update to official v90-beta2

#### v90.0-beta1
- Update to official v90-beta1

