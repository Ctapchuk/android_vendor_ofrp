# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers
#
# Modded for OrangeFox Recovery
# DarthJabba9 @ xda-developers
# 11 October 2020
# Version 2:0 - for dynamic partitions
#

DEBUGMSG="0";
[ "$DEBUGMSG" = "1" ] && set -o xtrace;

## AnyKernel setup
# begin properties
properties() { '
kernel.string=OrangeFox Initd Installer v2.0, by DarthJabba9
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;

## AnyKernel install
dump_boot;

# begin ramdisk changes

# check for system_root/dynamic partitions stuff #
THE_ROOT="";
DYNAMIC=$(getprop "ro.boot.dynamic_partitions");
ofox_tmp1=$(getprop "ro.build.system_root_image");

fox_block_device=$(getprop "orangefox.system.block_device");
[ -z "$fox_block_device" ] && fox_block_device=$(readlink /dev/block/mapper/system);

fox_mountpoint=$(getprop "orangefox.system.mount_point");
[ -z "$fox_mountpoint" ] && {
   tmp2=$(grep ^"/system_root | " /tmp/recovery.log);
   [ -n "$tmp2" -a "$ofox_tmp1" = "true" ] && fox_mountpoint="/system_root";
}

if [ -d "/system_root" -a "$ofox_tmp1" = "true" -a "$fox_mountpoint" = "/system_root" ]; then
   A_MOUNTED="1";
   THE_ROOT="/mnt/system";
   
   ui_print " ";
   ui_print "- OrangeFox: detected a system-as-root implementation ";

   # do we have a block device?
   if [ -z "$fox_block_device" ]; then
      tmp2=$(cat /etc/fstab | grep ' /system_root ');
      if [ -n "$tmp2" ]; then
	  fox_block_device=$(echo "$tmp2" | cut -f1 -d" "); # trim from the first whitespace
      fi
      
      if [ -z "$fox_block_device" ]; then
	 tmp2=/dev/block/bootdevice/by-name/system; # last resort
	 [ -e "$tmp2" ] && fox_block_device="$tmp2";
      fi
   fi

   # check again for the block device
   if [ -z "$fox_block_device" ]; then
      ui_print "OrangeFox: I cannot find the block device for the system partition. Quitting!";
      exit 1;
    fi

   # safe to proceed
   umount "$THE_ROOT" > /dev/null 2>&1;
   mkdir -p $THE_ROOT;
   
   echo "- OrangeFox - mounting $fox_block_device at $THE_ROOT ..." >> /tmp/recovery.log;   
   tmp2=$(blockdev --getro $fox_block_device); # get the read-only status
   [ "$tmp2" = "1" ] && blockdev --setrw $fox_block_device; # set r/w if necessary
   ui_print "- OrangeFox: mounting and setting up the system partition ... ";
   sleep 1;
   mount -w -t ext4 $fox_block_device $THE_ROOT;
   
   ui_print "- OrangeFox: Performing some checks ... ";
   sleep 1;
   tmp2=$(blockdev --getro $fox_block_device);
   [ "$tmp2" = "1" ] && blockdev --setrw $fox_block_device;
   
   echo "- Copying files manually..." >> /tmp/recovery.log;
   cp -f $home/ramdisk/init.dj9.rc $THE_ROOT;
   cp -Rf $home/ramdisk/sbin/ $THE_ROOT;
   cd $THE_ROOT;
else
   echo "- NOT system-as-root ..." >> /tmp/recovery.log;
   A_MOUNTED="";
fi
# end: system-as-root #

# init.rc
ui_print "- OrangeFox: Installing the init.d system ... ";
ui_print " "
backup_file "$THE_ROOT/"init.rc;
insert_line "$THE_ROOT/"init.rc "init.dj9.rc" before "on early-init" "import /init.dj9.rc";
# end ramdisk changes

write_boot;
## end install

# unmount whatever we mounted
if [ "$A_MOUNTED" = "1" ]; then
   sync;
   umount $THE_ROOT > /dev/null 2>&1;
fi
## end OrangeFox
