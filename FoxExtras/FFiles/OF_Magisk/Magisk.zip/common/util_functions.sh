############################################
# File for checking magisk version
############################################

MAGISK_VER="24.2"
MAGISK_VER_CODE=24200
