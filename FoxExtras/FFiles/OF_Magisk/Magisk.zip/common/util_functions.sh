############################################
# File for checking magisk version
############################################

MAGISK_VER="Canary_23016"
MAGISK_VER_CODE=23016
